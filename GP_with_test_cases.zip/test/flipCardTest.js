const assert =require('chai').assert;

describe('flipcard',function(){
    it('Should add the "flip" class to the card',function(){
        const card=document.createElement('div');
        flipCard.call(card);
        assert.isTrue(card.classList.contains('flip'));
    });
})