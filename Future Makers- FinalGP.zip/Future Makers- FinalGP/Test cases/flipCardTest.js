var assert =chai.assert;

describe('Testing the flipCard Function',function(){
    it('Test1: Should add the flip class to the card',function(){
        var card = document.createElement('div');
        flipCard.call(card);
        assert.isTrue(card.classList.contains('flip'));
    });

    it('Test 2: Should set the first card to the current card',function(){
        var card = document.createElement('div');
        var firstCard = document.createElement('div');
        hasFlippedCard = false;

        flipCard.call(card);

        assert.equal(firstCard, card);
        assert.isTrue(hasFlippedCard);
    });

    it('Test3: should set the second card to the current card', function(){
        var card = document.createElement('div');
        var firstCard = document.createElement('div');
        var secondCard = document.createElement('div');
        hasFlippedCard = true;

   
        flipCard.call(card);

   
        assert.equal(secondCard, card);
        assert.isFalse(hasFlippedCard);
    });

    it('Test4: Should not flip the card if the board is locked', function() {
       
        var card = document.createElement('div');
        lockBoard = true;
    
    
        flipCard.call(card);
    
        
        assert.isFalse(card.classList.contains('flip'));
    });

    it('Test5: should not flip the same card twice', function() {
        
        var card = document.createElement('div');
        firstCard = card;
    
       
        flipCard.call(card);
    
        
        assert.isFalse(card.classList.contains('flip'));
    });

});

